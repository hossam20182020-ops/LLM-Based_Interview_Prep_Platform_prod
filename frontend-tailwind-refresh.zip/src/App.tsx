import React from 'react'
import GenerateForm from './components/GenerateForm'
import QuestionList from './components/QuestionList'
import Stats from './components/Stats'

export default function App() {
  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-10 border-b bg-white/80 backdrop-blur">
        <div className="container max-w-5xl py-3 flex items-center justify-between">
          <h1 className="text-lg font-semibold">LLM Interview Prep</h1>
          <a href="https://vitejs.dev" target="_blank" className="text-sm opacity-70 hover:opacity-100">v1</a>
        </div>
      </header>

      <main className="container max-w-5xl py-6 grid gap-6 md:grid-cols-3">
        <section className="md:col-span-2 space-y-6">
          <GenerateForm onSaved={() => {}} />
          <QuestionList />
        </section>
        <aside className="space-y-6">
          <Stats />
        </aside>
      </main>

      <footer className="container max-w-5xl pb-10 pt-2 text-sm text-neutral-500">
        Built with FastAPI + React + PostgreSQL
      </footer>
    </div>
  )
}
